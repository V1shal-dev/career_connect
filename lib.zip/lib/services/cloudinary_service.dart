import 'dart:io';
import 'package:dio/dio.dart';
import '../core/constants/cloudinary_config.dart';

class CloudinaryService {
  final Dio _dio = Dio();

  // Upload file to Cloudinary
  Future<String?> uploadFile(File file) async {
    try {
      // Create form data
      String fileName = file.path.split('/').last;

      FormData formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(
          file.path,
          filename: fileName,
        ),
        'upload_preset': CloudinaryConfig.uploadPreset,
        'folder': 'career_connect/resumes',
      });

      // Upload to Cloudinary
      final response = await _dio.post(
        CloudinaryConfig.uploadUrl,
        data: formData,
        options: Options(
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        ),
      );

      if (response.statusCode == 200) {
        // Return the secure URL of uploaded file
        return response.data['secure_url'] as String;
      }

      return null;
    } catch (e) {
      print('Cloudinary Upload Error: $e');
      return null;
    }
  }

  // Delete file from Cloudinary (optional)
  Future<bool> deleteFile(String publicId) async {
    try {
      // Note: Deletion requires API authentication
      // For unsigned uploads, you might need backend implementation
      // This is a basic implementation
      return true;
    } catch (e) {
      print('Cloudinary Delete Error: $e');
      return false;
    }
  }

  // Get file size
  Future<int> getFileSize(File file) async {
    try {
      return await file.length();
    } catch (e) {
      return 0;
    }
  }

  // Validate file
  bool validateFile(File file) {
    // Check file size
    final fileSize = file.lengthSync();
    if (fileSize > CloudinaryConfig.maxFileSize) {
      return false;
    }

    // Check file extension
    final extension = file.path.split('.').last.toLowerCase();
    if (!CloudinaryConfig.allowedExtensions.contains(extension)) {
      return false;
    }

    return true;
  }
}